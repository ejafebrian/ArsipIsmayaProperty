import React from 'react';
import { Category, FilterOptions, DocumentType } from '../types';
import { Search, X, SlidersHorizontal, LayoutList, LayoutGrid, RotateCcw } from 'lucide-react';

interface FilterBarProps {
  filters: FilterOptions;
  setFilters: React.Dispatch<React.SetStateAction<FilterOptions>>;
  categories: Category[];
  availableAlphabetPrefixes: string[];
  viewMode: 'table' | 'grid';
  setViewMode: (mode: 'table' | 'grid') => void;
  onResetFilters: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  setFilters,
  categories,
  availableAlphabetPrefixes,
  viewMode,
  setViewMode,
  onResetFilters
}) => {
  const [showAdvanced, setShowAdvanced] = React.useState(false);

  const hasActiveFilters = Boolean(
    filters.searchQuery ||
    filters.kategoriId ||
    filters.abjadPrefix ||
    filters.tanggalAwal ||
    filters.tanggalAkhir ||
    filters.statusFisik ||
    filters.sifatSurat
  );

  return (
    <div className="bg-white border border-neutral-200 rounded-lg p-3 sm:p-4 mb-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)] no-print">
      {/* Row 1: Search Input & Quick Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
            placeholder="Cari nomor dokumen, perihal/judul, pengirim, penerima, atau keterangan..."
            className="w-full pl-9 pr-8 py-2 text-sm bg-neutral-50 hover:bg-neutral-100/70 focus:bg-white border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-800 transition-all"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters(prev => ({ ...prev, searchQuery: '' }))}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category dropdown & View Toggles */}
        <div className="flex items-center gap-2 shrink-0">
          <select
            value={filters.kategoriId}
            onChange={(e) => setFilters(prev => ({ ...prev, kategoriId: e.target.value }))}
            className="text-xs sm:text-sm py-2 px-3 bg-white border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-800"
          >
            <option value="">Semua Kategori</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                [{cat.abjadCode}] {cat.nama} ({cat.kode})
              </option>
            ))}
          </select>

          {/* Sort Selector */}
          <select
            value={filters.sortBy}
            onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value as FilterOptions['sortBy'] }))}
            className="text-xs sm:text-sm py-2 px-3 bg-white border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-800"
          >
            <option value="nomor_asc">Urut Abjad Nomor (A - Z)</option>
            <option value="nomor_desc">Urut Abjad Nomor (Z - A)</option>
            <option value="tanggal_desc">Tanggal Dokumen Terbaru</option>
            <option value="tanggal_asc">Tanggal Dokumen Terlama</option>
            <option value="judul_asc">Judul Perihal (A - Z)</option>
          </select>

          {/* Advanced toggle */}
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`p-2 border rounded-md text-xs font-medium transition-colors ${
              showAdvanced || hasActiveFilters
                ? 'bg-neutral-100 border-neutral-300 text-neutral-900'
                : 'bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50'
            }`}
            title="Filter Lanjutan"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          {/* View mode toggle */}
          <div className="hidden sm:flex items-center p-0.5 bg-neutral-100 rounded-md border border-neutral-200">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded transition-all ${
                viewMode === 'table' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500 hover:text-neutral-900'
              }`}
              title="Tampilan Tabel Rinci"
            >
              <LayoutList className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded transition-all ${
                viewMode === 'grid' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500 hover:text-neutral-900'
              }`}
              title="Tampilan Kartu Arsip"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Row 2: Alphabetical Index Bar (A, B, C, D, E...) */}
      <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-neutral-400 font-medium whitespace-nowrap shrink-0 mr-1 text-[11px] uppercase tracking-wider">
          Urut Abjad:
        </span>
        <button
          onClick={() => setFilters(prev => ({ ...prev, abjadPrefix: '' }))}
          className={`px-2 py-1 rounded text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
            !filters.abjadPrefix
              ? 'bg-neutral-900 text-white'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          Semua Abjad
        </button>

        {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'].map(char => {
          const isAvailable = availableAlphabetPrefixes.includes(char);
          const isSelected = filters.abjadPrefix === char;
          return (
            <button
              key={char}
              onClick={() => setFilters(prev => ({ ...prev, abjadPrefix: char }))}
              className={`w-6 h-6 rounded flex items-center justify-center font-mono text-xs font-medium whitespace-nowrap shrink-0 transition-all ${
                isSelected
                  ? 'bg-neutral-900 text-white font-bold'
                  : isAvailable
                  ? 'bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
                  : 'text-neutral-300 hover:text-neutral-500'
              }`}
              title={isAvailable ? `Dokumen dengan kode abjad ${char}` : `Belum ada dokumen abjad ${char}`}
            >
              {char}
            </button>
          );
        })}

        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="ml-auto inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-800 whitespace-nowrap shrink-0 pl-2"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filter</span>
          </button>
        )}
      </div>

      {/* Row 3: Collapsible Advanced Filter */}
      {showAdvanced && (
        <div className="mt-3 pt-3 border-t border-neutral-100 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block text-neutral-500 font-medium mb-1">Tanggal Mulai Dokumen</label>
            <input
              type="date"
              value={filters.tanggalAwal}
              onChange={(e) => setFilters(prev => ({ ...prev, tanggalAwal: e.target.value }))}
              className="w-full py-1.5 px-2 bg-neutral-50 border border-neutral-200 rounded text-xs"
            />
          </div>

          <div>
            <label className="block text-neutral-500 font-medium mb-1">Tanggal Sampai Dokumen</label>
            <input
              type="date"
              value={filters.tanggalAkhir}
              onChange={(e) => setFilters(prev => ({ ...prev, tanggalAkhir: e.target.value }))}
              className="w-full py-1.5 px-2 bg-neutral-50 border border-neutral-200 rounded text-xs"
            />
          </div>

          <div>
            <label className="block text-neutral-500 font-medium mb-1">Status Fisik Dokumen</label>
            <select
              value={filters.statusFisik}
              onChange={(e) => setFilters(prev => ({ ...prev, statusFisik: e.target.value }))}
              className="w-full py-1.5 px-2 bg-neutral-50 border border-neutral-200 rounded text-xs"
            >
              <option value="">Semua Status Fisik</option>
              <option value="Asli">Dokumen Asli</option>
              <option value="Salinan">Salinan / Legalisir</option>
              <option value="Digital">Digital / Softcopy</option>
            </select>
          </div>

          <div>
            <label className="block text-neutral-500 font-medium mb-1">Sifat / Urgensi Surat</label>
            <select
              value={filters.sifatSurat}
              onChange={(e) => setFilters(prev => ({ ...prev, sifatSurat: e.target.value }))}
              className="w-full py-1.5 px-2 bg-neutral-50 border border-neutral-200 rounded text-xs"
            >
              <option value="">Semua Sifat Surat</option>
              <option value="Biasa">Biasa</option>
              <option value="Penting">Penting</option>
              <option value="Rahasia">Rahasia</option>
              <option value="Segera">Segera</option>
            </select>
          </div>
        </div>
      )}

    </div>
  );
};
