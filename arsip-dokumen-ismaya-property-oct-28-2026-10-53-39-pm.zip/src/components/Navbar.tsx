import React from 'react';
import { AdminUser, DocumentType } from '../types';
import { 
  FileText, 
  Plus, 
  TableProperties, 
  Layers, 
  LogIn, 
  LogOut, 
  ShieldCheck, 
  Printer 
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  adminUser: AdminUser;
  onOpenLogin: () => void;
  onLogout: () => void;
  onOpenCreate: () => void;
  onOpenCategories: () => void;
  onOpenGoogleSheets: () => void;
  onOpenPrint: () => void;
  onOpenProfile: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  adminUser,
  onOpenLogin,
  onLogout,
  onOpenCreate,
  onOpenCategories,
  onOpenGoogleSheets,
  onOpenPrint,
  onOpenProfile,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-neutral-200 shadow-[0_1px_2px_rgba(0,0,0,0.03)] no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-8">
          
          {/* Zone 1: Single text element wordmark with brand logo */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="p-1 bg-white rounded border border-neutral-200/80 shadow-2xs flex items-center justify-center">
              <img 
                src="/assets/aistudio/436288cc-2e74-4fc9-b640-0cf371e4aa32_53fea3f7.png" 
                alt="ISMAYA PROPERTY" 
                className="w-9 h-7 object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-neutral-900 leading-tight whitespace-nowrap">
                ISMAYA PROPERTY
              </span>
              <span className="text-xs text-neutral-500 font-medium whitespace-nowrap">
                Sistem E-Arsip Dokumen
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-neutral-600">
            <button
              onClick={() => setActiveTab('semua')}
              className={`pb-1 text-sm transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'semua'
                  ? 'border-neutral-900 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              Semua Dokumen
            </button>
            <button
              onClick={() => setActiveTab('surat_masuk')}
              className={`pb-1 text-sm transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'surat_masuk'
                  ? 'border-neutral-900 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              Surat Masuk
            </button>
            <button
              onClick={() => setActiveTab('surat_keluar')}
              className={`pb-1 text-sm transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'surat_keluar'
                  ? 'border-neutral-900 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              Surat Keluar
            </button>
            <button
              onClick={() => setActiveTab('dokumen_legal')}
              className={`pb-1 text-sm transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === 'dokumen_legal'
                  ? 'border-neutral-900 text-neutral-900 font-semibold'
                  : 'border-transparent hover:text-neutral-900'
              }`}
            >
              Legalitas & SHM
            </button>
            <button
              onClick={onOpenCategories}
              className="pb-1 text-sm text-neutral-600 hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 border-b-2 border-transparent"
            >
              Kelola Kategori
            </button>
            <button
              onClick={onOpenGoogleSheets}
              className="pb-1 text-sm text-neutral-600 hover:text-neutral-900 transition-colors whitespace-nowrap shrink-0 border-b-2 border-transparent flex items-center gap-1.5"
            >
              <TableProperties className="w-3.5 h-3.5 text-emerald-600" />
              <span>Google Sheets</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action & Authentication Profile */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={onOpenPrint}
              title="Cetak Rekap Arsip"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Rekap</span>
            </button>

            {adminUser.isLoggedIn ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenProfile}
                  title="Buka Profil Administrator, Ganti Sandi, dan Riwayat Login"
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-800 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">{adminUser.namaLengkap || adminUser.username || 'Profil'}</span>
                  <span className="sm:hidden">Profil</span>
                </button>

                <button
                  onClick={onOpenCreate}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded-md shadow-sm transition-colors whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Arsip</span>
                </button>

                <button
                  onClick={onLogout}
                  title="Keluar dari sesi dan kembali ke halaman login"
                  className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-neutral-600 hover:text-rose-600 hover:bg-rose-50 border border-neutral-200 hover:border-rose-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5 text-neutral-500 hover:text-rose-600" />
                  <span className="hidden md:inline">Keluar</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors whitespace-nowrap shrink-0"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Login Admin</span>
              </button>
            )}
          </div>

        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="flex lg:hidden overflow-x-auto py-2 gap-4 text-xs font-medium text-neutral-600 border-t border-neutral-100">
          <button
            onClick={() => setActiveTab('semua')}
            className={`whitespace-nowrap shrink-0 ${activeTab === 'semua' ? 'text-neutral-900 font-bold' : ''}`}
          >
            Semua Dokumen
          </button>
          <button
            onClick={() => setActiveTab('surat_masuk')}
            className={`whitespace-nowrap shrink-0 ${activeTab === 'surat_masuk' ? 'text-neutral-900 font-bold' : ''}`}
          >
            Surat Masuk
          </button>
          <button
            onClick={() => setActiveTab('surat_keluar')}
            className={`whitespace-nowrap shrink-0 ${activeTab === 'surat_keluar' ? 'text-neutral-900 font-bold' : ''}`}
          >
            Surat Keluar
          </button>
          <button
            onClick={() => setActiveTab('dokumen_legal')}
            className={`whitespace-nowrap shrink-0 ${activeTab === 'dokumen_legal' ? 'text-neutral-900 font-bold' : ''}`}
          >
            Legalitas & SHM
          </button>
          <button
            onClick={onOpenCategories}
            className="whitespace-nowrap shrink-0 text-neutral-600"
          >
            Kategori
          </button>
          <button
            onClick={onOpenGoogleSheets}
            className="whitespace-nowrap shrink-0 text-emerald-700"
          >
            Google Sheets
          </button>
        </div>
      </div>
    </header>
  );
};
